#!/bin/bash

# Obtiene el nivel de la batería
battery_level=$(acpi -b | grep -P -o '[0-9]+(?=%)')

# Envía una notificación si la batería está por debajo del 20%
if [ "$battery_level" -le 22 ]; then
#    notify-send -u critical "Batería baja" "El nivel de la batería es $battery_level%."
	echo "󰞏󰞏󰞏󰞏 BATERÍA BAJA 󰞏󰞏󰞏󰞏"
else
	echo ""
fi


